
import json
import re
import ipaddress
from pathlib import Path
from collections import defaultdict

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = PROJECT_DIR / "working"
OUTPUTS_DIR = PROJECT_DIR / "outputs"

PATTERN = re.compile(r";([^;]*?)\s*->\s*$")


def extract_candidate(prompt):
    match = PATTERN.search(prompt)
    return match.group(1).strip() if match else None


def is_valid_ipv4(candidate):
    try:
        ipaddress.IPv4Address(candidate)
        return True
    except (ValueError, TypeError):
        return False


def load_jsonl(filename):
    with open(WORKING_DIR / filename, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


df = pd.read_csv(WORKING_DIR / "dataset_small.csv")

train = load_jsonl("dataset_train.jsonl")
test = load_jsonl("dataset_test.jsonl")

combined = train + test

print("=" * 60)
print("CIP-B107 - DATASET RECONCILIATION")
print("=" * 60)

# Compare CSV and JSONL records in their original order
mismatches = []

for index, (csv_row, json_record) in enumerate(
    zip(df.to_dict("records"), combined), start=1
):
    csv_ip = str(csv_row["ip"]).strip()
    json_ip = extract_candidate(json_record["prompt"])

    expected_label = (
        "negative" if csv_row["class"] == "N" else "positive"
    )
    actual_label = json_record["completion"].strip()

    if csv_ip != json_ip or expected_label != actual_label:
        mismatches.append({
            "record_number": index,
            "csv_ip": csv_ip,
            "jsonl_candidate": json_ip,
            "csv_class": csv_row["class"],
            "expected_label": expected_label,
            "actual_label": actual_label,
            "ip_matches": csv_ip == json_ip,
            "label_matches": expected_label == actual_label
        })

print("\n1. CSV AND JSONL COMPARISON")
print("CSV records:", len(df))
print("Combined JSONL records:", len(combined))
print("Mismatched records:", len(mismatches))

# Compare IPv4 validation counts
csv_valid = sum(
    is_valid_ipv4(str(ip).strip()) for ip in df["ip"]
)

json_valid = sum(
    is_valid_ipv4(extract_candidate(record["prompt"]))
    for record in combined
)

print("\n2. IPv4 VALIDATION COMPARISON")
print("CSV valid:", csv_valid)
print("JSONL valid:", json_valid)
print("Difference:", csv_valid - json_valid)

# Identify overlapping prompts and conflicting labels
train_map = defaultdict(set)
test_map = defaultdict(set)

for record in train:
    train_map[record["prompt"]].add(record["completion"].strip())

for record in test:
    test_map[record["prompt"]].add(record["completion"].strip())

overlapping_prompts = set(train_map) & set(test_map)

conflicting_prompts = [
    prompt for prompt in overlapping_prompts
    if train_map[prompt] != test_map[prompt]
]

print("\n3. PROMPT OVERLAP")
print("Overlapping prompts:", len(overlapping_prompts))
print("Overlapping prompts with conflicting labels:",
      len(conflicting_prompts))

# Check candidate strings with conflicting labels
candidate_labels = defaultdict(set)

for record in combined:
    candidate = extract_candidate(record["prompt"])
    candidate_labels[candidate].add(record["completion"].strip())

conflicting_candidates = {
    candidate: labels
    for candidate, labels in candidate_labels.items()
    if len(labels) > 1
}

print("\n4. CANDIDATE LABEL CONSISTENCY")
print("Candidates with conflicting labels:",
      len(conflicting_candidates))

# Save reconciliation details
mismatch_path = OUTPUTS_DIR / "dataset_mismatches.csv"

pd.DataFrame(mismatches).to_csv(mismatch_path, index=False)

print("\n5. OUTPUT")
print("Mismatch report:", mismatch_path)

if mismatches:
    print("\nFirst mismatches:")
    for item in mismatches[:10]:
        print(item)
else:
    print("All CSV and JSONL records match in order.")

print("\nReconciliation completed.")
print("=" * 60)
