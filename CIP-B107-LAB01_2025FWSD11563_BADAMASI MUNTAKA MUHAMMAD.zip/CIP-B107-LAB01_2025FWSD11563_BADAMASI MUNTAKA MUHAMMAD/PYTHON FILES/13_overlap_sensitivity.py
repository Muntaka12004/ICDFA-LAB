
from pathlib import Path
import json
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score
)

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"

predictions = pd.read_csv(
    OUTPUT_DIR / "model_predictions.csv"
)

def load_prompts(path):
    prompts = set()

    with path.open("r", encoding="utf-8") as file:
        for line in file:
            if line.strip():
                record = json.loads(line)
                prompts.add(record["prompt"].strip())

    return prompts

train_prompts = load_prompts(
    WORKING_DIR / "dataset_train.jsonl"
)

test_prompts = load_prompts(
    WORKING_DIR / "dataset_test.jsonl"
)

predictions["prompt"] = (
    predictions["prompt"].astype(str).str.strip()
)

shared_prompts = train_prompts.intersection(test_prompts)
unseen_prompts = test_prompts.difference(train_prompts)

# One row per unique prompt
unique_test = predictions.drop_duplicates(
    subset=["prompt"],
    keep="first"
).copy()

# Test records whose prompts never appeared in training
unseen_test = predictions[
    predictions["prompt"].isin(unseen_prompts)
].copy()

model_columns = {
    "Majority baseline": "majority_prediction",
    "Rule-based heuristic": "baseline_prediction",
    "TF-IDF Logistic Regression": "ml_prediction"
}

datasets = {
    "All test records": predictions,
    "Unique test prompts": unique_test,
    "Unseen test prompts only": unseen_test
}

results = []

for dataset_name, data in datasets.items():

    print("\n" + "=" * 65)
    print(dataset_name)
    print("=" * 65)
    print(f"Records evaluated: {len(data)}")
    print(f"Unique prompts: {data['prompt'].nunique()}")

    if data.empty:
        print("No records available.")
        continue

    for model_name, prediction_column in model_columns.items():

        actual = data["true_label"].astype(str).str.lower()
        predicted = (
            data[prediction_column].astype(str).str.lower()
        )

        row = {
            "evaluation_subset": dataset_name,
            "model": model_name,
            "records": len(data),
            "accuracy": accuracy_score(actual, predicted),
            "precision": precision_score(
                actual, predicted,
                pos_label="positive",
                zero_division=0
            ),
            "recall": recall_score(
                actual, predicted,
                pos_label="positive",
                zero_division=0
            ),
            "f1_score": f1_score(
                actual, predicted,
                pos_label="positive",
                zero_division=0
            )
        }

        results.append(row)

        print(
            f"\n{model_name}: "
            f"Accuracy={row['accuracy']:.4f}, "
            f"Precision={row['precision']:.4f}, "
            f"Recall={row['recall']:.4f}, "
            f"F1={row['f1_score']:.4f}"
        )

results_df = pd.DataFrame(results)

output_file = OUTPUT_DIR / "overlap_sensitivity_results.csv"
results_df.to_csv(output_file, index=False)

print("\nOVERLAP SUMMARY")
print("----------------")
print(f"Shared unique prompts: {len(shared_prompts)}")
print(f"Unseen unique test prompts: {len(unseen_prompts)}")

print("\nSaved:", output_file)
print("\nOverlap sensitivity analysis completed.")
