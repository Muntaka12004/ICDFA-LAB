
import hashlib
import csv
import getpass
from pathlib import Path
from datetime import datetime, timezone, timedelta

# Project folders
PROJECT_DIR = Path(__file__).resolve().parent.parent
ORIGINALS_DIR = PROJECT_DIR / "originals"
OUTPUTS_DIR = PROJECT_DIR / "outputs"

OUTPUTS_DIR.mkdir(exist_ok=True)

# West Africa Time (UTC+1)
wat = timezone(timedelta(hours=1))

# Record when this manifest is generated
manifest_time = datetime.now(wat).isoformat(timespec="seconds")
examiner = getpass.getuser()

def calculate_sha256(file_path):
    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:
        for chunk in iter(lambda: file.read(4096), b""):
            sha256.update(chunk)

    return sha256.hexdigest()

manifest = []

print("=" * 60)
print("CIP-B107 - DIGITAL EVIDENCE PRESERVATION")
print("=" * 60)

# Process every file directly inside originals
evidence_files = sorted(
    file for file in ORIGINALS_DIR.iterdir() if file.is_file()
)

for file_path in evidence_files:
    file_hash = calculate_sha256(file_path)
    file_size = file_path.stat().st_size

    modified_time = datetime.fromtimestamp(
        file_path.stat().st_mtime, tz=wat
    ).isoformat(timespec="seconds")

    manifest.append({
        "filename": file_path.name,
        "sha256": file_hash,
        "file_size_bytes": file_size,
        "manifest_creation_time_WAT": manifest_time,
        "last_modified_time_WAT": modified_time,
        "examiner": examiner,
        "transfer_source": "User-supplied assignment materials"
    })

    print(f"\nFile: {file_path.name}")
    print(f"SHA-256: {file_hash}")
    print(f"Size: {file_size} bytes")

# Save the manifest
manifest_path = OUTPUTS_DIR / "evidence_manifest.csv"

fieldnames = [
    "filename",
    "sha256",
    "file_size_bytes",
    "manifest_creation_time_WAT",
    "last_modified_time_WAT",
    "examiner",
    "transfer_source"
]

with open(manifest_path, "w", newline="", encoding="utf-8") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(manifest)

print("\n" + "=" * 60)
print(f"Total files processed: {len(manifest)}")
print(f"Manifest saved to: {manifest_path}")

if len(manifest) == 13:
    print("SUCCESS: All 13 files were hashed.")
else:
    print("WARNING: Expected 13 files. Check the originals folder.")

print("=" * 60)
