
import ipaddress
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

INPUT_FILE = ROOT / "outputs" / "context_extraction_audit.csv"
OUTPUT_FILE = ROOT / "outputs" / "context_validation_results.csv"
SUMMARY_FILE = ROOT / "outputs" / "context_validation_summary.txt"

df = pd.read_csv(INPUT_FILE)

results = []

for _, row in df.iterrows():
    candidates = str(row["extracted_candidates"]).split("; ")

    for candidate in candidates:
        if not candidate or candidate == "nan":
            continue

        try:
            ipaddress.IPv4Address(candidate)
            valid = True
            note = "Syntactically valid IPv4"
        except ipaddress.AddressValueError:
            valid = False
            note = "Invalid IPv4 syntax"

        results.append({
            "source_row": row["source_row"],
            "context": row["context"],
            "candidate": candidate,
            "ipv4_valid": valid,
            "validation_note": note
        })

validation = pd.DataFrame(results)
validation.to_csv(OUTPUT_FILE, index=False)

valid_count = int(validation["ipv4_valid"].sum())
invalid_count = len(validation) - valid_count

summary = [
    "STRICT VALIDATION OF CONTEXT-EXTRACTED CANDIDATES",
    "=" * 60,
    f"Total extracted candidate occurrences: {len(validation)}",
    f"Valid IPv4 candidates: {valid_count}",
    f"Invalid IPv4 candidates: {invalid_count}",
    "",
    "VALIDATION METHOD",
    "-" * 60,
    "Python ipaddress.IPv4Address",
    "",
    "INTERPRETATION",
    "-" * 60,
    "Regex identifies IPv4-shaped candidate strings.",
    "Strict validation checks whether each candidate is a valid IPv4 address.",
    "Neither operation establishes whether an address is malicious."
]

SUMMARY_FILE.write_text("\n".join(summary), encoding="utf-8")

print("\n".join(summary))
print("\nFiles created:")
print(OUTPUT_FILE)
print(SUMMARY_FILE)

print("\nVALIDATION BY STATUS:")
print(validation["ipv4_valid"].value_counts().to_string())
