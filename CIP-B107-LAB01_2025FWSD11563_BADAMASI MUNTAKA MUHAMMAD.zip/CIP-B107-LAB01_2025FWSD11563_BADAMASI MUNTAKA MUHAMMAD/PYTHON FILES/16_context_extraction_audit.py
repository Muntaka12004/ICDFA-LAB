
import re
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

INPUT_FILE = ROOT / "working" / "dataset_small.csv"
OUTPUT_FILE = ROOT / "outputs" / "context_extraction_audit.csv"
SUMMARY_FILE = ROOT / "outputs" / "context_extraction_summary.txt"

# Finds four groups of 1-3 digits separated by dots.
# This is a candidate extraction pattern, not IPv4 validation.
IP_PATTERN = re.compile(r"\d{1,3}(?:\.\d{1,3}){3}")

df = pd.read_csv(INPUT_FILE)

audit_rows = []

for index, row in df.iterrows():
    context = str(row["text"])
    supplied_candidate = str(row["ip"])

    matches = IP_PATTERN.findall(context)

    audit_rows.append({
        "source_row": index + 1,
        "context": context,
        "supplied_candidate": supplied_candidate,
        "extracted_candidates": "; ".join(matches),
        "extraction_count": len(matches),
        "supplied_candidate_found": supplied_candidate in matches
    })

audit = pd.DataFrame(audit_rows)
audit.to_csv(OUTPUT_FILE, index=False)

total = len(audit)
rows_with_matches = (audit["extraction_count"] > 0).sum()
rows_without_matches = (audit["extraction_count"] == 0).sum()
supplied_found = audit["supplied_candidate_found"].sum()
supplied_not_found = total - supplied_found
multiple_matches = (audit["extraction_count"] > 1).sum()

summary = [
    "CONTEXT-BASED CANDIDATE EXTRACTION AUDIT",
    "=" * 55,
    f"Total source records: {total}",
    f"Records with regex matches: {rows_with_matches}",
    f"Records without regex matches: {rows_without_matches}",
    f"Supplied candidates found among extracted matches: {supplied_found}",
    f"Supplied candidates not found among extracted matches: {supplied_not_found}",
    f"Records with multiple extracted matches: {multiple_matches}",
    "",
    "EXTRACTION PATTERN",
    "-" * 55,
    r"\d{1,3}(?:\.\d{1,3}){3}",
    "",
    "IMPORTANT",
    "-" * 55,
    "Regex matches are candidate strings only.",
    "They are not proof of valid IPv4 addresses.",
    "Strict IPv4 validation must be performed separately."
]

SUMMARY_FILE.write_text("\n".join(summary), encoding="utf-8")

print("\n".join(summary))
print("\nFiles created:")
print(OUTPUT_FILE)
print(SUMMARY_FILE)

if supplied_not_found:
    print("\nEXAMPLES OF SUPPLIED CANDIDATES NOT FOUND:")
    print(
        audit.loc[
            ~audit["supplied_candidate_found"],
            ["source_row", "supplied_candidate", "extracted_candidates", "context"]
        ].head(10).to_string(index=False)
    )
