
import sys
import platform
import subprocess
from pathlib import Path
from datetime import datetime
from importlib.metadata import version, PackageNotFoundError

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_FILE = PROJECT_ROOT / "environment.txt"

packages = [
    "pandas",
    "numpy",
    "scikit-learn",
    "matplotlib",
    "joblib"
]

lines = [
    "CIP-B107-LAB01 - ENVIRONMENT RECORD",
    "=" * 55,
    f"Recorded: {datetime.now().astimezone().isoformat(timespec='seconds')}",
    f"Python version: {sys.version}",
    f"Python executable: {sys.executable}",
    f"Operating system: {platform.platform()}",
    f"Machine architecture: {platform.machine()}",
    "",
    "KEY PACKAGE VERSIONS",
    "-" * 55
]

for package in packages:
    try:
        lines.append(f"{package}: {version(package)}")
    except PackageNotFoundError:
        lines.append(f"{package}: NOT INSTALLED")

lines.extend([
    "",
    "REPRODUCIBILITY NOTES",
    "-" * 55,
    "Model: TF-IDF character n-grams + Logistic Regression",
    "Vectorizer: analyzer='char', ngram_range=(2, 5), min_df=1",
    "Logistic Regression: class_weight='balanced', max_iter=2000",
    "Random state: 42",
    "Training data: supplied dataset_train.jsonl",
    "Testing data: supplied dataset_test.jsonl",
    "Evaluation: fixed supplied train/test split",
    "",
    "PACKAGE FREEZE",
    "-" * 55
])

result = subprocess.run(
    [sys.executable, "-m", "pip", "freeze"],
    capture_output=True,
    text=True
)

if result.returncode == 0:
    lines.append(result.stdout)
else:
    lines.append("Could not retrieve package list.")
    lines.append(result.stderr)

OUTPUT_FILE.write_text("\n".join(lines), encoding="utf-8")

print("ENVIRONMENT RECORD CREATED")
print("=" * 55)
print(f"Output: {OUTPUT_FILE}")
print(f"Python: {platform.python_version()}")
print(f"Operating system: {platform.system()}")
print("\nKey packages:")

for package in packages:
    try:
        print(f"{package}: {version(package)}")
    except PackageNotFoundError:
        print(f"{package}: NOT INSTALLED")
