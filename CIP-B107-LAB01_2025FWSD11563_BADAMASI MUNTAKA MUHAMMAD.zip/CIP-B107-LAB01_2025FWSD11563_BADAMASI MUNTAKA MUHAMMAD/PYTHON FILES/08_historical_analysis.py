
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"
CHART_DIR = OUTPUT_DIR / "charts"

CHART_DIR.mkdir(parents=True, exist_ok=True)

steps_file = WORKING_DIR / "fine_tuning_steps.txt"
results_file = WORKING_DIR / "result.csv"

steps_df = pd.read_csv(steps_file)
results_df = pd.read_csv(results_file)

# --------------------------------------------------
# 1. TRAINING LOSS COMPARISON
# --------------------------------------------------

plt.figure(figsize=(10, 5))

plt.plot(
    steps_df["step"],
    steps_df["training_loss"],
    label="fine_tuning_steps.txt",
    alpha=0.8
)

plt.plot(
    results_df["step"],
    results_df["training_loss"],
    label="result.csv",
    alpha=0.8
)

plt.title("Historical Fine-Tuning Training Loss")
plt.xlabel("Training Step")
plt.ylabel("Training Loss")
plt.legend()
plt.grid(True)
plt.tight_layout()

plt.savefig(CHART_DIR / "historical_training_loss.png", dpi=300)
plt.close()

# --------------------------------------------------
# 2. VALIDATION LOSS
# --------------------------------------------------

validation = results_df.dropna(subset=["validation_loss"])

plt.figure(figsize=(10, 5))

plt.plot(
    validation["step"],
    validation["validation_loss"],
    marker="o",
    markersize=3
)

plt.title("Historical Validation Loss")
plt.xlabel("Training Step")
plt.ylabel("Validation Loss")
plt.grid(True)
plt.tight_layout()

plt.savefig(CHART_DIR / "historical_validation_loss.png", dpi=300)
plt.close()

# --------------------------------------------------
# 3. VALIDATION ACCURACY
# --------------------------------------------------

validation_accuracy = results_df.dropna(
    subset=["validation_sequence_accuracy"]
)

plt.figure(figsize=(10, 5))

plt.plot(
    validation_accuracy["step"],
    validation_accuracy["validation_sequence_accuracy"],
    marker="o",
    markersize=3,
    label="Validation sequence accuracy"
)

plt.plot(
    validation_accuracy["step"],
    validation_accuracy["validation_token_accuracy"],
    marker=".",
    markersize=3,
    label="Validation token accuracy"
)

plt.title("Historical Validation Accuracy")
plt.xlabel("Training Step")
plt.ylabel("Accuracy")
plt.ylim(-0.05, 1.05)
plt.legend()
plt.grid(True)
plt.tight_layout()

plt.savefig(CHART_DIR / "historical_validation_accuracy.png", dpi=300)
plt.close()

# --------------------------------------------------
# 4. CLASSIFICATION METRICS
# --------------------------------------------------

metric_columns = [
    "classification/accuracy",
    "classification/precision",
    "classification/recall",
    "classification/auroc",
    "classification/auprc",
    "classification/f1.0"
]

classification = results_df.dropna(
    subset=metric_columns,
    how="all"
)

plt.figure(figsize=(10, 5))

for column in metric_columns:
    available = classification.dropna(subset=[column])

    if not available.empty:
        plt.plot(
            available["step"],
            available[column],
            marker="o",
            label=column.replace("classification/", "")
        )

plt.title("Historical Classification Metrics")
plt.xlabel("Training Step")
plt.ylabel("Metric Value")
plt.ylim(0, 1.05)
plt.legend()
plt.grid(True)
plt.tight_layout()

plt.savefig(CHART_DIR / "historical_classification_metrics.png", dpi=300)
plt.close()

# --------------------------------------------------
# 5. FINAL RECORDED CLASSIFICATION METRICS
# --------------------------------------------------

summary_lines = []

summary_lines.append("HISTORICAL FINE-TUNING ANALYSIS")
summary_lines.append("=" * 50)

summary_lines.append(
    f"Steps file records: {len(steps_df)}"
)
summary_lines.append(
    f"Result CSV records: {len(results_df)}"
)
summary_lines.append(
    f"Steps file final step: {steps_df['step'].max()}"
)
summary_lines.append(
    f"Result CSV final step: {results_df['step'].max()}"
)

summary_lines.append(
    f"Validation loss records: {results_df['validation_loss'].count()}"
)
summary_lines.append(
    f"Classification accuracy records: "
    f"{results_df['classification/accuracy'].count()}"
)

summary_lines.append("\nFINAL NON-NULL CLASSIFICATION METRICS")
summary_lines.append("-" * 50)

for column in metric_columns:
    available = results_df.dropna(subset=[column])

    if not available.empty:
        last_record = available.iloc[-1]
        value = last_record[column]

        summary_lines.append(
            f"{column}: {value:.6f} "
            f"(step {int(last_record['step'])})"
        )
    else:
        summary_lines.append(f"{column}: No recorded value")

summary_lines.append("\nTRAINING LOSS")
summary_lines.append("-" * 50)
summary_lines.append(
    f"Initial loss in steps file: "
    f"{steps_df.iloc[0]['training_loss']:.6f}"
)
summary_lines.append(
    f"Final loss in steps file: "
    f"{steps_df.iloc[-1]['training_loss']:.6f}"
)
summary_lines.append(
    f"Initial loss in result CSV: "
    f"{results_df.iloc[0]['training_loss']:.6f}"
)
summary_lines.append(
    f"Final loss in result CSV: "
    f"{results_df.iloc[-1]['training_loss']:.6f}"
)

summary_text = "\n".join(summary_lines)

summary_file = OUTPUT_DIR / "historical_analysis_summary.txt"
summary_file.write_text(summary_text, encoding="utf-8")

print(summary_text)

print("\nGENERATED CHARTS")
print("----------------")
for filename in [
    "historical_training_loss.png",
    "historical_validation_loss.png",
    "historical_validation_accuracy.png",
    "historical_classification_metrics.png"
]:
    print(CHART_DIR / filename)

print("\nHistorical analysis completed successfully.")
