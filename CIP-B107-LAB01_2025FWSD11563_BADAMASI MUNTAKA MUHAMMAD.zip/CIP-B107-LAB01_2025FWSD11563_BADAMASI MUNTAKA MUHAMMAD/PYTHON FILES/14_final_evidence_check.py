
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

required_files = [
    "environment.txt",

    "outputs/evidence_manifest.csv",
    "outputs/dataset_profile.txt",
    "outputs/ipv4_validation.csv",
    "outputs/candidate_review.csv",

    "outputs/context_extraction_audit.csv",
    "outputs/context_extraction_summary.txt",
    "outputs/context_validation_results.csv",
    "outputs/context_validation_summary.txt",
    "outputs/context_candidate_review.csv",
    "outputs/context_candidate_review_summary.txt",

    "outputs/model_metrics.csv",
    "outputs/model_predictions.csv",
    "outputs/model_evaluation.txt",
    "outputs/manual_review.csv",
    "outputs/historical_analysis_summary.txt",
    "outputs/prediction_audit_summary.csv",
    "outputs/train_test_shared_prompts.csv",
    "outputs/test_duplicate_prompts.csv",
    "outputs/train_test_label_conflicts.csv",
    "outputs/overlap_sensitivity_results.csv",
    "outputs/tfidf_logistic_regression.joblib",

    "outputs/charts/confusion_matrix_comparison.png",
    "outputs/charts/three_model_confusion_matrices.png",
    "outputs/charts/historical_training_loss.png",
    "outputs/charts/historical_validation_loss.png",
    "outputs/charts/historical_validation_accuracy.png",
    "outputs/charts/historical_classification_metrics.png",
]

required_scripts = [
    f"scripts/{i:02d}_{name}.py"
    for i, name in [
        (1, "evidence_preservation"),
        (2, "dataset_profile"),
        (3, "reconcile_datasets"),
        (4, "model_evaluation"),
        (5, "manual_review"),
        (6, "candidate_review"),
        (7, "inspect_historical_data"),
        (8, "historical_analysis"),
        (9, "majority_baseline"),
        (10, "prediction_audit"),
        (11, "inspect_error_context"),
        (12, "duplicate_audit"),
        (13, "overlap_sensitivity"),
        (14, "final_evidence_check"),
        (15, "capture_environment"),
        (16, "context_extraction_audit"),
        (17, "validate_extracted_candidates"),
        (18, "context_candidate_review"),
    ]
]

all_files = required_files + required_scripts

print("UPDATED FINAL PROJECT INVENTORY")
print("=" * 65)

missing = []

for relative_path in all_files:
    exists = (ROOT / relative_path).is_file()
    print(f"[{'OK' if exists else 'MISSING'}] {relative_path}")

    if not exists:
        missing.append(relative_path)

print("\nSUMMARY")
print("-" * 65)
print(f"Items checked: {len(all_files)}")
print(f"Present: {len(all_files) - len(missing)}")
print(f"Missing: {len(missing)}")

if missing:
    print("\nPlease investigate the missing files.")
else:
    print("\nAll inventoried files are present.")
