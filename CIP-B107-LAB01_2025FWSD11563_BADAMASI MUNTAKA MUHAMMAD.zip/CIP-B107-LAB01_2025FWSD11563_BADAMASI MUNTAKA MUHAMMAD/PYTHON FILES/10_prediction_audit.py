
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "outputs"

prediction_file = OUTPUT_DIR / "model_predictions.csv"
metrics_file = OUTPUT_DIR / "model_metrics.csv"

predictions = pd.read_csv(prediction_file)
metrics = pd.read_csv(metrics_file)

print("PREDICTION FILE AUDIT")
print("=" * 60)

print(f"Total test predictions: {len(predictions)}")

print("\nAVAILABLE COLUMNS")
print(predictions.columns.tolist())

print("\nMODEL METRICS")
print(metrics.to_string(index=False))

# Identify errors for each model
model_columns = {
    "Majority-class baseline": "majority_prediction",
    "Rule-based IPv4 heuristic": "baseline_prediction",
    "TF-IDF Logistic Regression": "ml_prediction"
}

for model_name, prediction_column in model_columns.items():
    if prediction_column not in predictions.columns:
        print(f"\nMissing prediction column: {prediction_column}")
        continue

    actual = predictions["true_label"].astype(str).str.strip().str.lower()
    predicted = (
        predictions[prediction_column]
        .astype(str).str.strip().str.lower()
    )

    errors = predictions.loc[actual != predicted].copy()

    print(f"\n{model_name}")
    print("-" * 60)
    print(f"Incorrect predictions: {len(errors)}")

    if errors.empty:
        print("No incorrect predictions.")
    else:
        display_columns = [
            column for column in [
                "candidate",
                "true_label",
                prediction_column
            ]
            if column in errors.columns
        ]

        print(errors[display_columns].to_string(index=False))

# Export a simple audit summary
summary = []

for model_name, prediction_column in model_columns.items():
    if prediction_column not in predictions.columns:
        continue

    actual = predictions["true_label"].astype(str).str.strip().str.lower()
    predicted = (
        predictions[prediction_column]
        .astype(str).str.strip().str.lower()
    )

    summary.append({
        "model": model_name,
        "test_records": len(predictions),
        "correct_predictions": int((actual == predicted).sum()),
        "incorrect_predictions": int((actual != predicted).sum())
    })

audit_df = pd.DataFrame(summary)
audit_path = OUTPUT_DIR / "prediction_audit_summary.csv"
audit_df.to_csv(audit_path, index=False)

print("\nAUDIT SUMMARY")
print(audit_df.to_string(index=False))
print(f"\nSaved: {audit_path}")
print("\nPrediction audit completed.")
