
import json
import re
import ipaddress
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay
)
import joblib


# --------------------------------------------------
# 1. PROJECT PATHS
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"
CHART_DIR = OUTPUT_DIR / "charts"

OUTPUT_DIR.mkdir(exist_ok=True)
CHART_DIR.mkdir(exist_ok=True)


# --------------------------------------------------
# 2. LOAD THE FIXED DATASETS
# --------------------------------------------------

def load_jsonl(file_path):
    records = []

    with open(file_path, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip():
                records.append(json.loads(line))

    return pd.DataFrame(records)


train_df = load_jsonl(WORKING_DIR / "dataset_train.jsonl")
test_df = load_jsonl(WORKING_DIR / "dataset_test.jsonl")

print("TRAINING AND TEST DATA")
print("----------------------")
print(f"Training records: {len(train_df)}")
print(f"Testing records: {len(test_df)}")


# --------------------------------------------------
# 3. EXTRACT IP CANDIDATES
# --------------------------------------------------

CANDIDATE_PATTERN = re.compile(r";([^;]*?)\s*->\s*$")


def extract_candidate(prompt):
    match = CANDIDATE_PATTERN.search(str(prompt))

    if match:
        return match.group(1).strip()

    return ""


def is_valid_ipv4(candidate):
    try:
        ipaddress.IPv4Address(candidate)
        return True
    except ipaddress.AddressValueError:
        return False


train_df["candidate"] = train_df["prompt"].apply(extract_candidate)
test_df["candidate"] = test_df["prompt"].apply(extract_candidate)


# --------------------------------------------------
# 4. PREPARE LABELS
# --------------------------------------------------

X_train = train_df["prompt"].astype(str)
X_test = test_df["prompt"].astype(str)

y_train = train_df["completion"].astype(str).str.strip().str.lower()
y_test = test_df["completion"].astype(str).str.strip().str.lower()

allowed_labels = {"positive", "negative"}

if not set(y_train).issubset(allowed_labels):
    raise ValueError("Unexpected label found in training data.")

if not set(y_test).issubset(allowed_labels):
    raise ValueError("Unexpected label found in testing data.")


# --------------------------------------------------
# 5. RULE-BASED BASELINE
# --------------------------------------------------

# This is a syntax heuristic only.
# It does NOT identify malicious IP addresses.

baseline_predictions = [
    "positive" if is_valid_ipv4(candidate) else "negative"
    for candidate in test_df["candidate"]
]


# --------------------------------------------------
# 6. MACHINE LEARNING MODEL
# --------------------------------------------------

model = Pipeline([
    (
        "tfidf",
        TfidfVectorizer(
            analyzer="char",
            ngram_range=(2, 5),
            min_df=1
        )
    ),
    (
        "classifier",
        LogisticRegression(
            class_weight="balanced",
            max_iter=2000,
            random_state=42
        )
    )
])

print("\nTraining Logistic Regression model...")

model.fit(X_train, y_train)

ml_predictions = model.predict(X_test)

positive_index = list(model.classes_).index("positive")
positive_probabilities = model.predict_proba(X_test)[:, positive_index]


# --------------------------------------------------
# 7. EVALUATION FUNCTION
# --------------------------------------------------

LABEL_ORDER = ["negative", "positive"]


def evaluate_model(model_name, actual, predicted):

    return {
        "model": model_name,
        "accuracy": accuracy_score(actual, predicted),
        "precision": precision_score(
            actual, predicted,
            pos_label="positive",
            zero_division=0
        ),
        "recall": recall_score(
            actual, predicted,
            pos_label="positive",
            zero_division=0
        ),
        "f1_score": f1_score(
            actual, predicted,
            pos_label="positive",
            zero_division=0
        )
    }


baseline_metrics = evaluate_model(
    "Rule-based IPv4 syntax heuristic",
    y_test,
    baseline_predictions
)

ml_metrics = evaluate_model(
    "TF-IDF + Logistic Regression",
    y_test,
    ml_predictions
)

metrics_df = pd.DataFrame([
    baseline_metrics,
    ml_metrics
])


# --------------------------------------------------
# 8. SAVE MODEL METRICS
# --------------------------------------------------

metrics_path = OUTPUT_DIR / "model_metrics.csv"
metrics_df.to_csv(metrics_path, index=False)


# --------------------------------------------------
# 9. SAVE INDIVIDUAL PREDICTIONS
# --------------------------------------------------

predictions_df = pd.DataFrame({
    "test_record": range(1, len(test_df) + 1),
    "prompt": X_test,
    "candidate": test_df["candidate"],
    "true_label": y_test,
    "baseline_prediction": baseline_predictions,
    "ml_prediction": ml_predictions,
    "ml_positive_probability": positive_probabilities
})

predictions_df["baseline_correct"] = (
    predictions_df["true_label"] ==
    predictions_df["baseline_prediction"]
)

predictions_df["ml_correct"] = (
    predictions_df["true_label"] ==
    predictions_df["ml_prediction"]
)

predictions_path = OUTPUT_DIR / "model_predictions.csv"
predictions_df.to_csv(predictions_path, index=False)


# --------------------------------------------------
# 10. CONFUSION MATRICES
# --------------------------------------------------

baseline_cm = confusion_matrix(
    y_test,
    baseline_predictions,
    labels=LABEL_ORDER
)

ml_cm = confusion_matrix(
    y_test,
    ml_predictions,
    labels=LABEL_ORDER
)

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

ConfusionMatrixDisplay(
    confusion_matrix=baseline_cm,
    display_labels=LABEL_ORDER
).plot(ax=axes[0], colorbar=False)

axes[0].set_title("Rule-Based Baseline")

ConfusionMatrixDisplay(
    confusion_matrix=ml_cm,
    display_labels=LABEL_ORDER
).plot(ax=axes[1], colorbar=False)

axes[1].set_title("TF-IDF + Logistic Regression")

plt.tight_layout()

chart_path = CHART_DIR / "confusion_matrix_comparison.png"
plt.savefig(chart_path, dpi=300, bbox_inches="tight")
plt.close()


# --------------------------------------------------
# 11. SAVE TRAINED MODEL
# --------------------------------------------------

model_path = OUTPUT_DIR / "tfidf_logistic_regression.joblib"
joblib.dump(model, model_path)


# --------------------------------------------------
# 12. CHECK TRAIN/TEST OVERLAP
# --------------------------------------------------

train_prompts = set(X_train)
test_prompts = set(X_test)

train_candidates = set(train_df["candidate"])
test_candidates = set(test_df["candidate"])

overlapping_prompts = train_prompts.intersection(test_prompts)
overlapping_candidates = train_candidates.intersection(test_candidates)


# --------------------------------------------------
# 13. SAVE EVALUATION REPORT
# --------------------------------------------------

report_path = OUTPUT_DIR / "model_evaluation.txt"

with open(report_path, "w", encoding="utf-8") as report:

    report.write("MODEL EVALUATION REPORT\n")
    report.write("=======================\n\n")

    report.write(f"Training records: {len(train_df)}\n")
    report.write(f"Testing records: {len(test_df)}\n\n")

    report.write("METRICS COMPARISON\n")
    report.write("------------------\n")
    report.write(metrics_df.to_string(index=False))
    report.write("\n\n")

    report.write("BASELINE CLASSIFICATION REPORT\n")
    report.write("------------------------------\n")
    report.write(
        classification_report(
            y_test,
            baseline_predictions,
            labels=LABEL_ORDER,
            zero_division=0
        )
    )

    report.write("\nMACHINE LEARNING CLASSIFICATION REPORT\n")
    report.write("-------------------------------------\n")
    report.write(
        classification_report(
            y_test,
            ml_predictions,
            labels=LABEL_ORDER,
            zero_division=0
        )
    )

    report.write("\nDATA OVERLAP CHECK\n")
    report.write("------------------\n")
    report.write(
        f"Identical prompts in both splits: "
        f"{len(overlapping_prompts)}\n"
    )
    report.write(
        f"Shared candidate strings: "
        f"{len(overlapping_candidates)}\n"
    )

    report.write(
        "\nLIMITATIONS\n"
        "-----------\n"
        "The rule-based baseline checks IPv4 syntax only. "
        "It does not identify malicious activity.\n"
        "The machine learning model predicts the supplied dataset "
        "labels, not whether an IP address is malicious.\n"
        "The supplied train/test split is retained without "
        "reshuffling. Shared prompts and candidates may affect "
        "the independence of the evaluation.\n"
    )


# --------------------------------------------------
# 14. DISPLAY RESULTS
# --------------------------------------------------

print("\nMODEL PERFORMANCE COMPARISON")
print("-----------------------------")
print(metrics_df.to_string(index=False))

print("\nBASELINE CONFUSION MATRIX")
print(baseline_cm)

print("\nMACHINE LEARNING CONFUSION MATRIX")
print(ml_cm)

print("\nDATA OVERLAP")
print(f"Identical prompts: {len(overlapping_prompts)}")
print(f"Shared candidates: {len(overlapping_candidates)}")

print("\nFILES GENERATED")
print(metrics_path)
print(predictions_path)
print(chart_path)
print(report_path)
print(model_path)

print("\nModel evaluation completed successfully.")
