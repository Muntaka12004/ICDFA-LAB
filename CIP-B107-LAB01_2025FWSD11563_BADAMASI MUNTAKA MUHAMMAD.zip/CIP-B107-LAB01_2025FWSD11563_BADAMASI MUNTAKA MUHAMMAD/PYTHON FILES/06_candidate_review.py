
import re
import ipaddress
from pathlib import Path

import pandas as pd


# --------------------------------------------------
# 1. PROJECT PATHS
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"

INPUT_FILE = WORKING_DIR / "dataset_small.csv"
OUTPUT_FILE = OUTPUT_DIR / "candidate_review.csv"

OUTPUT_DIR.mkdir(exist_ok=True)


# --------------------------------------------------
# 2. REGEX CANDIDATE IDENTIFICATION
# --------------------------------------------------

# Detects four groups of 1-3 digits separated by dots.
# This checks the shape, not whether the address is valid.

IP_REGEX = re.compile(
    r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])"
)


def regex_match(candidate):
    return bool(IP_REGEX.fullmatch(str(candidate).strip()))


# --------------------------------------------------
# 3. STRICT IPV4 VALIDATION
# --------------------------------------------------

def validate_ipv4(candidate):
    try:
        ipaddress.IPv4Address(str(candidate).strip())
        return True
    except ipaddress.AddressValueError:
        return False


# --------------------------------------------------
# 4. SOURCE LABEL MAPPING
# --------------------------------------------------

# Based on the supplied historical preprocessing logic:
# N = negative
# A, B, C and E = positive

def map_source_label(source_class):

    source_class = str(source_class).strip().upper()

    if source_class == "N":
        return "negative"

    if source_class in {"A", "B", "C", "E"}:
        return "positive"

    return "unknown"


# --------------------------------------------------
# 5. ANALYST OBSERVATIONS
# --------------------------------------------------

def create_analyst_note(candidate, regex_result, valid_result):

    if not regex_result:
        return "Candidate does not match the expected four-octet IPv4 pattern."

    if not valid_result:
        return "Regex matched, but strict IPv4 validation failed."

    address = ipaddress.IPv4Address(candidate)

    if address == ipaddress.IPv4Address("0.0.0.0"):
        return "Valid IPv4 syntax; unspecified address requiring context."

    if address == ipaddress.IPv4Address("255.255.255.255"):
        return "Valid IPv4 syntax; limited broadcast address."

    if address.is_private:
        return "Valid IPv4 syntax; private or special-purpose range. Examine context."

    if address.is_global:
        return "Valid IPv4 syntax; globally reachable classification. Not evidence of maliciousness."

    return "Valid IPv4 syntax; special-purpose or reserved address requiring context."


# --------------------------------------------------
# 6. LOAD ORIGINAL WORKING DATASET
# --------------------------------------------------

if not INPUT_FILE.exists():
    raise FileNotFoundError(f"Dataset not found: {INPUT_FILE}")

df = pd.read_csv(INPUT_FILE)

required_columns = {"ip", "class", "text"}

if not required_columns.issubset(df.columns):
    raise ValueError(
        f"Dataset must contain these columns: {sorted(required_columns)}"
    )


# --------------------------------------------------
# 7. EXAMINE EVERY SOURCE RECORD
# --------------------------------------------------

review_records = []

for index, row in df.iterrows():

    candidate = str(row["ip"]).strip()
    context = str(row["text"])

    regex_result = regex_match(candidate)
    valid_result = validate_ipv4(candidate)
    source_label = map_source_label(row["class"])

    note = create_analyst_note(
        candidate,
        regex_result,
        valid_result
    )

    review_records.append({
        "source_row": index + 1,
        "context": context,
        "candidate": candidate,
        "regex_match": regex_result,
        "ipv4_valid": valid_result,
        "source_label": source_label,
        "analyst_note": note
    })


# --------------------------------------------------
# 8. CREATE REVIEW DATAFRAME
# --------------------------------------------------

review_df = pd.DataFrame(review_records)

review_df.to_csv(OUTPUT_FILE, index=False)


# --------------------------------------------------
# 9. GENERATE SUMMARY
# --------------------------------------------------

print("IP CANDIDATE REVIEW")
print("===================")

print(f"Total source records: {len(review_df)}")
print(f"Regex matches: {int(review_df['regex_match'].sum())}")
print(f"Strictly valid IPv4: {int(review_df['ipv4_valid'].sum())}")
print(f"Invalid IPv4 candidates: {int((~review_df['ipv4_valid']).sum())}")

print("\nSOURCE LABEL DISTRIBUTION")
print("-------------------------")
print(review_df["source_label"].value_counts().to_string())

print("\nREGEX AND VALIDATION COMPARISON")
print("-------------------------------")

print(
    pd.crosstab(
        review_df["regex_match"],
        review_df["ipv4_valid"],
        rownames=["Regex match"],
        colnames=["IPv4 valid"]
    )
)

print("\nSAMPLE RECORDS")
print("--------------")

print(
    review_df[
        [
            "source_row",
            "candidate",
            "regex_match",
            "ipv4_valid",
            "source_label",
            "analyst_note"
        ]
    ].head(15).to_string(index=False)
)

print("\nOUTPUT FILE")
print(OUTPUT_FILE)

print("\nCandidate review completed successfully.")
