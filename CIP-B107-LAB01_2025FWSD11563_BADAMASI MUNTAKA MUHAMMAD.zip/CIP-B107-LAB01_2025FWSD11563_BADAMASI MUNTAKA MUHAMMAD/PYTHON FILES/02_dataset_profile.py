
import json
import re
import ipaddress
from pathlib import Path
from collections import Counter

import pandas as pd

# Project directories
PROJECT_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = PROJECT_DIR / "working"
OUTPUTS_DIR = PROJECT_DIR / "outputs"

OUTPUTS_DIR.mkdir(exist_ok=True)

# Extract IP candidate from the JSONL prompt
CANDIDATE_PATTERN = re.compile(r";([^;]*?)\s*->\s*$")


def extract_candidate(prompt):
    match = CANDIDATE_PATTERN.search(prompt)
    return match.group(1).strip() if match else None


# Validate IPv4 addresses
def validate_ipv4(candidate):
    if not candidate:
        return False, "Candidate extraction failed"

    try:
        ipaddress.IPv4Address(candidate)
        return True, "Valid IPv4"
    except ValueError:
        return False, "Invalid IPv4"


# Read JSONL files
def load_jsonl(filename):
    records = []

    with open(WORKING_DIR / filename, encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as error:
                print(f"JSON error in {filename}, line {line_number}: {error}")
                raise

    return records


print("=" * 65)
print("CIP-B107 - DATASET PROFILING AND IPv4 VALIDATION")
print("=" * 65)

# 1. Profile CSV dataset
df = pd.read_csv(WORKING_DIR / "dataset_small.csv")

print("\n1. CSV DATASET")
print("Total records:", len(df))
print("Columns:", df.columns.tolist())
print("Duplicate complete rows:", df.duplicated().sum())

print("\nMissing values:")
print(df.isnull().sum().to_string())

print("\nOriginal class distribution:")
print(df["class"].value_counts().to_string())

# 2. Validate IP candidates in CSV
validation_records = []

for _, row in df.iterrows():
    candidate = str(row["ip"]).strip()
    valid, reason = validate_ipv4(candidate)

    validation_records.append({
        "source": "dataset_small.csv",
        "candidate": candidate,
        "label": row["class"],
        "valid_ipv4": valid,
        "validation_result": reason
    })

csv_validity = Counter(
    record["valid_ipv4"] for record in validation_records
)

print("\n2. CSV IPv4 VALIDATION")
print("Valid IPv4 candidates:", csv_validity[True])
print("Invalid IPv4 candidates:", csv_validity[False])

# 3. Load training and testing datasets
train = load_jsonl("dataset_train.jsonl")
test = load_jsonl("dataset_test.jsonl")

print("\n3. JSONL DATASETS")
print("Training records:", len(train))
print("Testing records:", len(test))

for name, records in [("Training", train), ("Testing", test)]:
    labels = Counter(
        record["completion"].strip() for record in records
    )
    print(f"{name} label distribution:", dict(labels))

# Validate candidates extracted from JSONL prompts
for filename, records in [
    ("dataset_train.jsonl", train),
    ("dataset_test.jsonl", test)
]:
    for record in records:
        candidate = extract_candidate(record["prompt"])
        valid, reason = validate_ipv4(candidate)

        validation_records.append({
            "source": filename,
            "candidate": candidate,
            "label": record["completion"].strip(),
            "valid_ipv4": valid,
            "validation_result": reason
        })

# 4. Check training/testing overlap
train_prompts = {record["prompt"] for record in train}
test_prompts = {record["prompt"] for record in test}

train_candidates = {
    extract_candidate(record["prompt"]) for record in train
}
test_candidates = {
    extract_candidate(record["prompt"]) for record in test
}

prompt_overlap = len(train_prompts.intersection(test_prompts))
candidate_overlap = len(train_candidates.intersection(test_candidates))

print("\n4. TRAIN/TEST OVERLAP")
print("Identical prompts in both datasets:", prompt_overlap)
print("Shared candidate strings:", candidate_overlap)

# 5. Save IPv4 validation results
validation_df = pd.DataFrame(validation_records)

print("\n5. COMBINED IPv4 VALIDATION")
print(
    validation_df.groupby(
        ["source", "valid_ipv4"]
    ).size().to_string()
)

validation_path = OUTPUTS_DIR / "ipv4_validation.csv"
validation_df.to_csv(validation_path, index=False)

# 6. Save profile summary
summary_path = OUTPUTS_DIR / "dataset_profile.txt"

with open(summary_path, "w", encoding="utf-8") as file:
    file.write("CIP-B107 DATASET PROFILE\n")
    file.write("=" * 40 + "\n")
    file.write(f"CSV records: {len(df)}\n")
    file.write(f"Training records: {len(train)}\n")
    file.write(f"Testing records: {len(test)}\n")
    file.write(f"CSV duplicate rows: {df.duplicated().sum()}\n")
    file.write(f"Identical train/test prompts: {prompt_overlap}\n")
    file.write(f"Shared train/test candidates: {candidate_overlap}\n\n")
    file.write(
        validation_df.groupby(
            ["source", "valid_ipv4"]
        ).size().to_string()
    )

print("\n6. OUTPUT FILES")
print("Validation details:", validation_path)
print("Profile summary:", summary_path)

print("\nProfiling completed.")
print("=" * 65)
