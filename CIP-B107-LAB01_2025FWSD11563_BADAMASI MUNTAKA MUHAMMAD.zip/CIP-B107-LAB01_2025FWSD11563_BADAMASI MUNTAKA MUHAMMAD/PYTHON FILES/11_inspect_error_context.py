
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
file_path = BASE_DIR / "outputs" / "model_predictions.csv"

df = pd.read_csv(file_path)

cases = [
    ("TF-IDF misclassification", "256.0.1.26"),
    ("Rule-based misclassification", "0.0.0.0"),
]

for title, candidate in cases:
    print("\n" + "=" * 75)
    print(title)
    print("=" * 75)

    selected = df[df["candidate"].astype(str) == candidate]

    if selected.empty:
        print("No matching records found.")
        continue

    for _, row in selected.iterrows():
        print(f"\nTest record: {row['test_record']}")
        print(f"Candidate: {row['candidate']}")
        print(f"Actual label: {row['true_label']}")
        print(f"Rule prediction: {row['baseline_prediction']}")
        print(f"ML prediction: {row['ml_prediction']}")

        if "ml_positive_probability" in df.columns:
            print(
                "ML positive probability: "
                f"{row['ml_positive_probability']}"
            )

        print("\nOriginal prompt/context:")
        print(row["prompt"])

print("\nError-context inspection completed.")
