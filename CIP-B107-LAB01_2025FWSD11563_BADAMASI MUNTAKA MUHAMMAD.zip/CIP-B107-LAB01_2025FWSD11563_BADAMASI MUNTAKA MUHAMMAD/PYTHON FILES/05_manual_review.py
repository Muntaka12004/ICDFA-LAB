
import ipaddress
from pathlib import Path

import pandas as pd


# --------------------------------------------------
# 1. PROJECT PATHS
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "outputs"

INPUT_FILE = OUTPUT_DIR / "model_predictions.csv"
OUTPUT_FILE = OUTPUT_DIR / "manual_review.csv"


# --------------------------------------------------
# 2. SELECT EIGHT TEST RECORDS
# --------------------------------------------------

# These records represent correct predictions, incorrect
# predictions, invalid addresses, and special-purpose addresses.

SELECTED_RECORDS = [1, 2, 9, 14, 20, 22, 43, 44]


# --------------------------------------------------
# 3. MANUAL EXAMINATION NOTES
# --------------------------------------------------

ANALYST_NOTES = {
    1: "Invalid IPv4: first octet exceeds 255.",
    2: "Syntactically valid IPv4 address.",
    9: "Valid private IPv4 address appearing in a URL path; context requires examination.",
    14: "Valid IPv4 syntax, but surrounding text resembles a software version identifier.",
    20: "Invalid IPv4: first octet exceeds 255.",
    22: "Invalid IPv4: first octet exceeds 255; ML incorrectly predicted positive.",
    43: "Syntactically valid limited broadcast address.",
    44: "Syntactically valid unspecified address; dataset label is negative."
}


# --------------------------------------------------
# 4. IPV4 VALIDATION AND CLASSIFICATION
# --------------------------------------------------

def examine_ipv4(candidate):

    try:
        address = ipaddress.IPv4Address(str(candidate).strip())

        if address == ipaddress.IPv4Address("0.0.0.0"):
            category = "Unspecified address"

        elif address == ipaddress.IPv4Address("255.255.255.255"):
            category = "Limited broadcast address"

        elif address.is_private:
            category = "Private or special-purpose address"

        elif address.is_global:
            category = "Globally reachable address"

        else:
            category = "Other special-purpose address"

        return {
            "ipv4_valid": True,
            "address_category": category
        }

    except ipaddress.AddressValueError:
        return {
            "ipv4_valid": False,
            "address_category": "Invalid IPv4 address"
        }


# --------------------------------------------------
# 5. LOAD MODEL PREDICTIONS
# --------------------------------------------------

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"Prediction file not found: {INPUT_FILE}"
    )

predictions = pd.read_csv(INPUT_FILE)

required_columns = {
    "test_record",
    "candidate",
    "true_label",
    "baseline_prediction",
    "ml_prediction",
    "ml_positive_probability",
    "baseline_correct",
    "ml_correct"
}

missing_columns = required_columns.difference(predictions.columns)

if missing_columns:
    raise ValueError(
        f"Missing required columns: {sorted(missing_columns)}"
    )


# --------------------------------------------------
# 6. SELECT RECORDS FOR EXAMINATION
# --------------------------------------------------

review_df = predictions[
    predictions["test_record"].isin(SELECTED_RECORDS)
].copy()

review_df = review_df.sort_values("test_record")

if len(review_df) != len(SELECTED_RECORDS):
    raise ValueError(
        "One or more selected test records were not found."
    )


# --------------------------------------------------
# 7. PERFORM IPV4 EXAMINATION
# --------------------------------------------------

examination_results = review_df["candidate"].apply(examine_ipv4)

review_df["ipv4_valid"] = [
    result["ipv4_valid"]
    for result in examination_results
]

review_df["address_category"] = [
    result["address_category"]
    for result in examination_results
]

review_df["analyst_observation"] = (
    review_df["test_record"].map(ANALYST_NOTES)
)


# --------------------------------------------------
# 8. PREPARE THE REVIEW TABLE
# --------------------------------------------------

review_columns = [
    "test_record",
    "candidate",
    "true_label",
    "baseline_prediction",
    "ml_prediction",
    "ml_positive_probability",
    "baseline_correct",
    "ml_correct",
    "ipv4_valid",
    "address_category",
    "analyst_observation"
]

review_df = review_df[review_columns]


# --------------------------------------------------
# 9. SAVE THE MANUAL REVIEW
# --------------------------------------------------

review_df.to_csv(OUTPUT_FILE, index=False)


# --------------------------------------------------
# 10. DISPLAY RESULTS
# --------------------------------------------------

print("MANUAL EXAMINATION RESULTS")
print("==========================")

print(review_df.to_string(index=False))

print("\nEXAMINATION SUMMARY")
print("-------------------")

print(f"Records examined: {len(review_df)}")
print(
    "Syntactically valid IPv4 candidates:",
    int(review_df["ipv4_valid"].sum())
)
print(
    "Invalid IPv4 candidates:",
    int((~review_df["ipv4_valid"]).sum())
)
print(
    "ML correct predictions:",
    int(review_df["ml_correct"].sum())
)
print(
    "ML incorrect predictions:",
    int((~review_df["ml_correct"]).sum())
)

print("\nOUTPUT FILE")
print(OUTPUT_FILE)

print("\nManual examination completed successfully.")
