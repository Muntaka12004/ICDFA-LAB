
from pathlib import Path
import json
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"

def load_jsonl(path):
    records = []

    with path.open("r", encoding="utf-8") as file:
        for line in file:
            if line.strip():
                records.append(json.loads(line))

    return pd.DataFrame(records)

train = load_jsonl(WORKING_DIR / "dataset_train.jsonl")
test = load_jsonl(WORKING_DIR / "dataset_test.jsonl")

# Normalise prompt and label fields
for df in [train, test]:
    df["prompt"] = df["prompt"].astype(str).str.strip()
    df["completion"] = (
        df["completion"].astype(str).str.strip().str.lower()
    )

# --------------------------------------------------
# 1. EXACT PROMPT OVERLAP
# --------------------------------------------------

train_prompts = set(train["prompt"])
test_prompts = set(test["prompt"])

shared_prompts = train_prompts.intersection(test_prompts)

print("TRAIN/TEST OVERLAP")
print("=" * 55)
print(f"Training records: {len(train)}")
print(f"Testing records: {len(test)}")
print(f"Unique training prompts: {len(train_prompts)}")
print(f"Unique testing prompts: {len(test_prompts)}")
print(f"Shared unique prompts: {len(shared_prompts)}")

# --------------------------------------------------
# 2. LABEL CONFLICTS IN SHARED PROMPTS
# --------------------------------------------------

conflicts = []

for prompt in sorted(shared_prompts):
    train_labels = set(
        train.loc[train["prompt"] == prompt, "completion"]
    )
    test_labels = set(
        test.loc[test["prompt"] == prompt, "completion"]
    )

    if train_labels != test_labels:
        conflicts.append({
            "prompt": prompt,
            "training_labels": ";".join(sorted(train_labels)),
            "testing_labels": ";".join(sorted(test_labels))
        })

print(f"Shared prompts with label conflicts: {len(conflicts)}")

# --------------------------------------------------
# 3. DUPLICATE TEST PROMPTS
# --------------------------------------------------

test_duplicates = test[
    test.duplicated(subset=["prompt"], keep=False)
].copy()

test_duplicate_summary = (
    test_duplicates.groupby("prompt")
    .agg(
        occurrences=("prompt", "size"),
        labels=("completion", lambda x: ";".join(sorted(set(x))))
    )
    .reset_index()
)

print("\nDUPLICATE TEST PROMPTS")
print("=" * 55)
print(f"Rows involved in repeated prompts: {len(test_duplicates)}")
print(f"Unique repeated prompts: {len(test_duplicate_summary)}")

if not test_duplicate_summary.empty:
    print(test_duplicate_summary.to_string(index=False))

# --------------------------------------------------
# 4. EXPORT EVIDENCE
# --------------------------------------------------

overlap_path = OUTPUT_DIR / "train_test_shared_prompts.csv"
duplicate_path = OUTPUT_DIR / "test_duplicate_prompts.csv"
conflict_path = OUTPUT_DIR / "train_test_label_conflicts.csv"

pd.DataFrame({
    "shared_prompt": sorted(shared_prompts)
}).to_csv(overlap_path, index=False)

test_duplicate_summary.to_csv(duplicate_path, index=False)
pd.DataFrame(conflicts).to_csv(conflict_path, index=False)

print("\nGENERATED FILES")
print(overlap_path)
print(duplicate_path)
print(conflict_path)

print("\nDuplicate audit completed.")
