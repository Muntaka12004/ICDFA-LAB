
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"

files = {
    "FINE-TUNING STEPS": WORKING_DIR / "fine_tuning_steps.txt",
    "RESULT CSV": WORKING_DIR / "result.csv",
}

for title, file_path in files.items():
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)

    if not file_path.exists():
        print(f"FILE NOT FOUND: {file_path}")
        continue

    try:
        df = pd.read_csv(file_path)

        print(f"\nFile: {file_path.name}")
        print(f"Shape: {df.shape}")

        print("\nCOLUMN NAMES")
        print(list(df.columns))

        print("\nDATA TYPES")
        print(df.dtypes.to_string())

        print("\nNON-NULL VALUE COUNTS")
        print(df.notna().sum().to_string())

        print("\nFIRST 5 RECORDS")
        print(df.head().to_string(index=False))

        print("\nLAST 5 RECORDS")
        print(df.tail().to_string(index=False))

    except Exception as error:
        print(f"Inspection error: {error}")

print("\nHistorical data inspection completed.")
