
from pathlib import Path
import json
from collections import Counter

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    ConfusionMatrixDisplay
)

BASE_DIR = Path(__file__).resolve().parent.parent
WORKING_DIR = BASE_DIR / "working"
OUTPUT_DIR = BASE_DIR / "outputs"
CHART_DIR = OUTPUT_DIR / "charts"

CHART_DIR.mkdir(parents=True, exist_ok=True)

TRAIN_FILE = WORKING_DIR / "dataset_train.jsonl"
PREDICTIONS_FILE = OUTPUT_DIR / "model_predictions.csv"

# --------------------------------------------------
# 1. READ TRAINING LABELS
# --------------------------------------------------

training_labels = []

with TRAIN_FILE.open("r", encoding="utf-8") as file:
    for line in file:
        if line.strip():
            record = json.loads(line)
            label = record["completion"].strip().lower()
            training_labels.append(label)

label_counts = Counter(training_labels)

majority_label, majority_count = label_counts.most_common(1)[0]

print("TRAINING LABEL DISTRIBUTION")
print("---------------------------")
for label, count in sorted(label_counts.items()):
    print(f"{label}: {count}")

print(f"\nMajority class: {majority_label}")
print(f"Majority class records: {majority_count}")

# --------------------------------------------------
# 2. LOAD EXISTING TEST PREDICTIONS
# --------------------------------------------------

predictions = pd.read_csv(PREDICTIONS_FILE)

required_columns = [
    "true_label",
    "baseline_prediction",
    "ml_prediction"
]

missing = [
    column for column in required_columns
    if column not in predictions.columns
]

if missing:
    raise ValueError(
        f"Missing required columns in model_predictions.csv: {missing}"
    )

predictions["true_label"] = (
    predictions["true_label"].astype(str).str.strip().str.lower()
)

# --------------------------------------------------
# 3. GENERATE MAJORITY-CLASS PREDICTIONS
# --------------------------------------------------

predictions["majority_prediction"] = majority_label

predictions["majority_correct"] = (
    predictions["true_label"] == predictions["majority_prediction"]
)

predictions.to_csv(PREDICTIONS_FILE, index=False)

# --------------------------------------------------
# 4. EVALUATE ALL THREE MODELS
# --------------------------------------------------

models = {
    "Majority-class baseline": "majority_prediction",
    "Rule-based IPv4 heuristic": "baseline_prediction",
    "TF-IDF Logistic Regression": "ml_prediction"
}

results = []
confusion_matrices = {}

labels = ["negative", "positive"]

for model_name, prediction_column in models.items():

    actual = predictions["true_label"]
    predicted = (
        predictions[prediction_column].astype(str).str.strip().str.lower()
    )

    results.append({
        "model": model_name,
        "accuracy": accuracy_score(actual, predicted),
        "precision": precision_score(
            actual, predicted, pos_label="positive", zero_division=0
        ),
        "recall": recall_score(
            actual, predicted, pos_label="positive", zero_division=0
        ),
        "f1_score": f1_score(
            actual, predicted, pos_label="positive", zero_division=0
        )
    })

    confusion_matrices[model_name] = confusion_matrix(
        actual, predicted, labels=labels
    )

metrics_df = pd.DataFrame(results)
metrics_df.to_csv(OUTPUT_DIR / "model_metrics.csv", index=False)

# --------------------------------------------------
# 5. DISPLAY RESULTS
# --------------------------------------------------

print("\nTHREE-MODEL PERFORMANCE COMPARISON")
print("----------------------------------")
print(metrics_df.to_string(index=False, float_format=lambda x: f"{x:.6f}"))

for model_name, matrix in confusion_matrices.items():
    print(f"\n{model_name} confusion matrix")
    print("Rows = actual; columns = predicted")
    print("Label order: negative, positive")
    print(matrix)

# --------------------------------------------------
# 6. CREATE THREE CONFUSION MATRIX CHARTS
# --------------------------------------------------

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

for ax, (model_name, matrix) in zip(
    axes, confusion_matrices.items()
):
    display = ConfusionMatrixDisplay(
        confusion_matrix=matrix,
        display_labels=labels
    )

    display.plot(
        ax=ax,
        colorbar=False,
        values_format="d"
    )

    ax.set_title(model_name)

plt.tight_layout()
plt.savefig(
    CHART_DIR / "three_model_confusion_matrices.png",
    dpi=300
)
plt.close()

print("\nUPDATED OUTPUTS")
print("----------------")
print(OUTPUT_DIR / "model_metrics.csv")
print(PREDICTIONS_FILE)
print(CHART_DIR / "three_model_confusion_matrices.png")

print("\nMajority-class baseline evaluation completed.")
