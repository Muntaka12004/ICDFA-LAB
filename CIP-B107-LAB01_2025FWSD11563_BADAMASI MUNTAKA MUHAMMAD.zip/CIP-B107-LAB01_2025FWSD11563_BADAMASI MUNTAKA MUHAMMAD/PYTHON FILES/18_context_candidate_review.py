
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

SOURCE_FILE = ROOT / "working" / "dataset_small.csv"
EXTRACTION_FILE = ROOT / "outputs" / "context_validation_results.csv"

OUTPUT_FILE = ROOT / "outputs" / "context_candidate_review.csv"
SUMMARY_FILE = ROOT / "outputs" / "context_candidate_review_summary.txt"

source = pd.read_csv(SOURCE_FILE)
extracted = pd.read_csv(EXTRACTION_FILE)

# Map each source row to its original candidate and class.
source = source.reset_index().rename(columns={"index": "source_row"})
source["source_row"] += 1
source["ip"] = source["ip"].astype(str)

source_map = source[["source_row", "ip", "class"]].rename(
    columns={
        "ip": "supplied_candidate",
        "class": "original_class"
    }
)

review = extracted.merge(
    source_map,
    on="source_row",
    how="left"
)

review["is_supplied_candidate"] = (
    review["candidate"] == review["supplied_candidate"]
)

# Preserve the original class and document the historical label mapping.
review["source_label"] = review["original_class"].apply(
    lambda value: "negative" if str(value).strip().upper() == "N"
    else "positive"
)

review["analyst_note"] = review.apply(
    lambda row: (
        "Supplied dataset candidate"
        if row["is_supplied_candidate"]
        else "Additional candidate extracted from context"
    ) + (
        "; syntactically valid IPv4"
        if row["ipv4_valid"]
        else "; invalid IPv4 syntax"
    ),
    axis=1
)

columns = [
    "source_row",
    "context",
    "candidate",
    "original_class",
    "source_label",
    "is_supplied_candidate",
    "ipv4_valid",
    "analyst_note"
]

review = review[columns]
review.to_csv(OUTPUT_FILE, index=False)

total = len(review)
valid = int(review["ipv4_valid"].sum())
invalid = total - valid
supplied = int(review["is_supplied_candidate"].sum())
additional = total - supplied

summary = [
    "COMPREHENSIVE CONTEXT CANDIDATE REVIEW",
    "=" * 60,
    f"Original source records: {len(source)}",
    f"Extracted candidate occurrences: {total}",
    f"Supplied candidate occurrences: {supplied}",
    f"Additional extracted occurrences: {additional}",
    f"Valid IPv4 occurrences: {valid}",
    f"Invalid IPv4 occurrences: {invalid}",
    f"Unique candidate strings: {review['candidate'].nunique()}",
    "",
    "SOURCE LABEL DISTRIBUTION",
    "-" * 60,
    review["source_label"].value_counts().to_string(),
    "",
    "VALIDATION BY CANDIDATE TYPE",
    "-" * 60,
    pd.crosstab(
        review["is_supplied_candidate"],
        review["ipv4_valid"]
    ).to_string(),
    "",
    "NOTE",
    "-" * 60,
    "Occurrences are not unique IP addresses.",
    "Source labels are inherited from the original dataset.",
    "Positive does not mean malicious.",
    "IPv4 validity does not establish forensic relevance."
]

SUMMARY_FILE.write_text("\n".join(summary), encoding="utf-8")

print("\n".join(summary))
print("\nFiles created:")
print(OUTPUT_FILE)
print(SUMMARY_FILE)
