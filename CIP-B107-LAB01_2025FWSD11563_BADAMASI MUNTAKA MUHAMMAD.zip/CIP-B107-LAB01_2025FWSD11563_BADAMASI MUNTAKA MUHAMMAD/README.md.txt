# CIP-B107-LAB01: AI-Assisted IP Evidence Identification and Model Evaluation

## 1. Project Overview

This project investigates the use of regular expressions, strict IPv4 address validation, and offline machine learning to identify IP-address candidates in supplied digital forensic text records.

The investigation compares a rule-based IPv4 syntax heuristic with a TF-IDF and Logistic Regression classifier. It also examines historical fine-tuning records supplied with the dataset.

The system is intended to support forensic analysts. It does not determine whether an IP address is malicious.

## 2. Project Objectives

- Preserve and document the supplied evidence files.
- Profile and reconcile the supplied CSV and JSONL datasets.
- Extract IP-shaped candidate strings from source context using regular expressions.
- Validate candidate strings using Python's IPv4 address parser.
- Compare rule-based classification with offline machine learning.
- Examine historical training and evaluation records.
- Investigate prediction errors and repeated records.
- Document limitations and forensic interpretation.

## 3. Project Structure

```text
CIP-B107-LAB01/
├── originals/       # Preserved original supplied files
├── working/         # Working copies of supplied datasets
├── scripts/         # Python analysis scripts
├── outputs/         # Generated evidence and analysis results
│   └── charts/      # Generated charts
├── report/          # Final report and executive briefing
├── venv/            # Local Python virtual environment
├── environment.txt  # Python and package environment record
└── README.md
```

## 4. Technologies Used

- Python 3.12
- pandas
- NumPy
- scikit-learn
- Matplotlib
- Python `ipaddress` module
- Regular expressions
- VS Code and PowerShell

Refer to `environment.txt` for recorded package versions.

## 5. Methodology

### Evidence preservation and profiling

The supplied files were preserved and documented using SHA-256 hashes. Dataset records, labels, duplicates, and IPv4 syntax were examined.

### Context-based candidate extraction

A regular expression was applied to the original context field to identify IPv4-shaped strings. The extracted candidates were compared with the candidates supplied in the original dataset.

### Strict IPv4 validation

Python's `ipaddress.IPv4Address` was used to distinguish syntactically valid IPv4 addresses from invalid candidates.

### Machine learning evaluation

A character-level TF-IDF vectorizer and Logistic Regression classifier were trained using the supplied training dataset and evaluated against the supplied test dataset.

The evaluation also included:
- A majority-class baseline.
- A rule-based IPv4 syntax heuristic.
- Confusion matrices and classification metrics.
- Manual examination of selected records.
- Duplicate and train/test overlap analysis.

### Historical training analysis

The supplied historical training log and result file were inspected and plotted. These historical results were not treated as a newly reproduced fine-tuning experiment.

## 6. Important Findings

The original CSV contained 229 records.

Context-based extraction identified 289 candidate occurrences, representing 105 unique candidate strings. Strict validation classified 261 occurrences as valid IPv4 and 28 as invalid.

The additional context-derived candidates were retained separately from the supplied candidates because their forensic relevance cannot automatically be inferred from the original record label.

The offline TF-IDF Logistic Regression model achieved 97.83% accuracy on the supplied 46-record test set. Duplicate and overlap analysis showed that the test set was not fully independent of the training data. Therefore, this result should not be interpreted as proof of generalization to unseen forensic datasets.

## 7. Reproducibility

Activate the virtual environment in PowerShell:

```powershell
.\venv\Scripts\Activate.ps1
```

Run the analysis scripts from the project root in their intended sequence:

1. Evidence preservation and dataset profiling.
2. Dataset reconciliation.
3. Model evaluation and manual review.
4. Candidate review and historical analysis.
5. Majority baseline and prediction audits.
6. Duplicate and overlap sensitivity analysis.
7. Environment capture.
8. Context extraction and strict validation.
9. Comprehensive context candidate review.

Individual scripts are stored in the `scripts/` directory. Generated outputs are stored in `outputs/`.

Do not execute the legacy API upload or fine-tuning job scripts as part of reproducing the offline analysis.

## 8. Limitations

- The supplied dataset is limited in size.
- The test set contains repeated and overlapping prompts.
- The positive source label does not mean that an address is malicious.
- Syntactic IPv4 validity does not establish forensic relevance or routability.
- Additional addresses extracted from context inherit the source record's context, not an independently verified label.
- Historical fine-tuning metrics are supplied historical results, not a newly reproduced experiment.
- Model performance on this dataset does not establish performance on unrelated forensic datasets.

## 9. Ethical and Forensic Considerations

The results should be treated as decision-support evidence. An analyst must review the original context, validate candidate addresses, and investigate relevant evidence before making a forensic conclusion.

No IP address should be classified as malicious solely because it was extracted or classified as positive by the model.

## 10. Submission Contents

The final submission should include the signed report, reproducible scripts, evidence manifest, candidate review files, prediction results, charts, environment record, README, executive briefing, and selected genuine screenshots.

The virtual environment and unrelated or sensitive files should not be included in the submission archive.